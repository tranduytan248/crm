# Y9 — TAB "CHUẨN BỊ TRƯỚC BÃO" TRONG DASHBOARD CHỈ HUY
# (bản giao AI code v1.0 — PM chốt 30/07/2026; làm sau Y8; phối hợp K3/chiến dịch gia cố sẵn có)

> **Vấn đề nghiệp vụ:** Mô phỏng bão cho ra KẾ HOẠCH (hạ tải, tiếp dầu, kê cao, điều máy nổ) nhưng chưa có màn nào theo dõi việc THI HÀNH trước giờ đổ bộ: đội nào đã đi kiểm trạm nào, trạm nào chưa ai phụ trách. Tab này là "phòng đếm ngược" của giai đoạn TRƯỚC BÃO — số hóa đúng khối chuẩn bị của QĐ 2512 §3.1.2b (gia cố nhà trạm, tủ cáp, nhiên liệu 3 ngày, kê cao máy nổ, phát quang…).
> Ràng buộc chung + tự tra số migration: như file Y1–Y4. Mọi số bấm được ra danh sách chứng minh.

## 0. VỊ TRÍ & CẤU TRÚC
- Màn Dashboard chỉ huy thêm **thanh Tabs trên đầu**: **[Điều hành]** (nội dung 2 nhịp v5 + Y8, giữ nguyên) · **[Chuẩn bị trước bão]** (tab mới). ⚠ Điều này sửa chốt v5 "một trang hai nhịp" → ghi errata vào tài liệu audit: "Dashboard = 2 tab; tab Điều hành giữ luật 2 nhịp — PM duyệt 30/07".
- Tab Trước bão **gắn với một CHIẾN DỊCH CHUẨN BỊ** đang mở (mục 1). Không có chiến dịch → màn trống trạng thái: "Chưa có chiến dịch chuẩn bị bão — tạo từ Kết quả mô phỏng ([Xác nhận áp dụng]) hoặc nút [+ Mở chiến dịch chuẩn bị]".
- Khi tab Trước bão có việc quá hạn/thiếu phân công, tab hiện badge số đỏ để người ở tab Điều hành biết mà sang.

## 1. CHIẾN DỊCH CHUẨN BỊ BÃO (tái dùng nền chiến dịch K3 — không xây hệ mới)
- Nguồn tạo: (a) tự sinh khi BCH bấm [Xác nhận áp dụng] ở Kết quả mô phỏng (kế hoạch gia cố thành đầu việc); (b) tạo tay [+ Mở chiến dịch chuẩn bị] chọn hồ sơ bão + phạm vi trạm (mặc định = mọi trạm trong vùng dự báo của mô phỏng; sửa được).
- Mỗi trạm trong chiến dịch có: **đầu việc kiểm tra/gia cố** (checklist seed từ QĐ 2512 §3.1.2b: chốt cửa + xiết đai tủ/hộp cáp · gia cố cột chống/dây co · phát quang cây · kiểm tiếp đất-chống sét · nhiên liệu đủ ≥3 ngày · kê cao máy nổ nếu trạm ngập sử — kèm các việc riêng từ kế hoạch mô phỏng: hạ tải cấp N, điều máy nổ…) + **trạng thái**: CHƯA ĐI · ĐANG KIỂM · **ĐÃ KIỂM ✓** (bắt buộc ≥1 ảnh hiện trường) · ⚠ CÓ TỒN TẠI (kiểm xong nhưng phát hiện việc chưa xử được — ghi chú bắt buộc).
- Đội báo qua đúng kênh sẵn có: màn Hiện trường (checklist Y6 tái dùng) hoặc Telegram `/kiemtra <mã trạm>` (+ảnh). Chiến dịch đóng khi bão đổ bộ hoặc BCH đóng tay; toàn bộ có audit.

## 2. NGƯỜI QUẢN LÝ BÃO THEO TRẠM ("nhân viên gần trạm")
- Bảng mới `phan_cong_quan_ly_baos` (chien_dich_id, ma_tram, thanh_vien_id, nguon_goi_y, thoi_diem, nguoi_gan). Mỗi trạm trong chiến dịch **đúng MỘT người quản lý bão** (unique theo chiến dịch+trạm); một người nhận được nhiều trạm nhưng UI cảnh báo khi >5 trạm/người.
- **Máy gợi ý "gần trạm" — minh bạch, 3 bậc** (hiện lý do cạnh tên): (1) thành viên đội có **tọa độ điểm trực** gần trạm nhất (thêm 2 cột tùy chọn `toa_do_diem_truc` vào bảng thành viên đội — pg/65; nhập ở màn Đội, KHÔNG bắt buộc, KHÔNG lưu địa chỉ nhà dạng chữ); (2) chưa có tọa độ → thành viên đội đang phụ trách **cụm/đơn vị** chứa trạm; (3) fallback: nhân sự quản lý trạm sẵn có (`nhan_su_trams`). Người gán bấm chấp nhận hoặc chọn tay; nút "Gán nhanh toàn bộ theo gợi ý" cho BCH.
- Gán xong → Telegram tự nhắn người được gán: danh sách trạm + checklist + hạn (outbox E4); người này là đầu mối nhận cảnh báo của các trạm đó suốt chiến dịch (mất điện, cạn dầu…).

## 3. CÁC Ô CỦA TAB TRƯỚC BÃO (bố cục 2 cột; mọi số drill-down)
Hàng đầu — **dải đếm ngược**: tên bão · cấp gió · "⏱ còn Xh tới đổ bộ" (từ hồ sơ bão của chiến dịch) · tiến độ tổng "Sẵn sàng a/b trạm".
1. **Tiến độ kiểm tra trạm** (ô chính): 4 số CHƯA ĐI / ĐANG KIỂM / ĐÃ KIỂM / ⚠ TỒN TẠI + thanh tiến độ; drill-down **theo khu vực TTVT** (tái dùng component khu vực của Y8) → danh sách trạm + người quản lý bão + giờ kiểm + ảnh.
2. **Phân công quản lý bão**: "x/y trạm đã có người phụ trách" + danh sách đỏ "trạm CHƯA ai nhận" (bấm → dialog gán, có gợi ý mục 2) + phân bố tải "người nhận nhiều nhất: N trạm".
3. **Nhiên liệu & máy nổ** (QĐ 2512: tối thiểu 3 ngày): trạm vùng dự báo đủ dầu ≥3 ngày x/y (đọc bồn dầu trạm) · máy nổ sẵn sàng tại các kho theo khu vực (thanh phân đoạn — component kho sẵn có).
4. **Việc gia cố từ mô phỏng**: hạ tải đã làm x/y · kê cao x/y · điều máy nổ đã tới x/y — khớp kế hoạch đã Xác nhận áp dụng (một nguồn với màn Kết quả mô phỏng).
5. **⭐ Trạm trọng yếu trong vùng dự báo** (Y8): trạng thái chuẩn bị riêng, chưa ĐÃ KIỂM → dòng đỏ nằm đầu.
6. **⚠ Thiếu dữ liệu chặn đánh giá**: trạm thiếu cấp gió chịu được / thiếu tọa độ / trạm chưa có nhân sự liên lạc (Telegram) — "sửa ngay" link về danh mục (đúng triết lý engine không đoán).
7. **Kênh liên lạc sẵn sàng**: % người quản lý bão đã liên kết Telegram; ai chưa liên kết → danh sách gọi.

## 4. DỮ LIỆU & API
Migration mới (số tự tra): bảng `phan_cong_quan_ly_baos` + 2 cột `toa_do_diem_truc_lat/lng` (NULL được) vào thành viên đội + trạng thái kiểm tra trạm trong items chiến dịch (nếu K3 chưa có) + seed checklist chuẩn bị theo QĐ 2512 §3.1.2b. `fn/sp`: `sp_phan_cong_quan_ly_bao` (unique, audit) · `fn_goi_y_quan_ly_bao(ma_tram)` (3 bậc + lý do; khoảng cách bằng công thức haversine SQL sẵn có của `tram_gan_toi`) · `fn_dashboard_truoc_bao` (một hàm trả đủ số cho 7 ô — FE không tự đếm) · `sp_kiem_tra_tram_bao_cao` (trạng thái + ảnh + tồn tại). API `DashboardTruocBao` + lệnh Telegram `/kiemtra`. SignalR cập nhật ≤3s.

## 5. NGHIỆM THU
- [ ] Xác nhận áp dụng mô phỏng → chiến dịch chuẩn bị tự mở, tab hiện dải đếm ngược + đủ 7 ô; không chiến dịch → màn trống đúng thiết kế; tab Điều hành giữ nguyên 2 nhịp.
- [ ] Gợi ý quản lý bão đúng 3 bậc kèm lý do (dựng 3 ca: có tọa độ điểm trực / chỉ có cụm / chỉ có nhân sự trạm); gán xong Telegram tới đúng người; trạm gán 2 người → sp chặn; 1 người >5 trạm → UI cảnh báo.
- [ ] Đội báo `/kiemtra` kèm ảnh → trạm sang ĐÃ KIỂM ≤3s trên tab; báo không ảnh → giữ ĐANG KIỂM + nhắc "cần ảnh"; ca ⚠ TỒN TẠI bắt buộc ghi chú.
- [ ] Ô nhiên liệu: hạ mức dầu 1 trạm dưới 3 ngày → rơi khỏi số "đủ", vào danh sách drill-down; ô gia cố khớp 100% màn Kết quả mô phỏng.
- [ ] Drill-down khu vực dùng chung component Y8; mọi số = tổng danh sách; errata "Dashboard 2 tab" đã ghi vào tài liệu audit; migration idempotent; lint/test xanh.
