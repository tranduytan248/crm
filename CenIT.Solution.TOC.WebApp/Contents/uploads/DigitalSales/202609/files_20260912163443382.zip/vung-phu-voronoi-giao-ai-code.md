# Y4b — NÂNG CẤP LỚP VÙNG PHỦ SÓNG: TỪ VÒNG TRÒN CHỒNG LẤN → ĐA GIÁC VORONOI KHÔNG TRÙNG
# (bản giao AI code v1.0 — PM chốt 30/07/2026; làm NGAY SAU Y4, sửa trên module `LopVungPhuSong.js`)

> **Ý tưởng (PM chốt theo ảnh mẫu):** hai trạm gần nhau thì vùng phủ KHÔNG đè lên nhau — ranh giới là đường trung trực giữa hai trạm (mỗi điểm thuộc về trạm gần nhất = sơ đồ Voronoi/Thiessen); chỗ thưa trạm, mép vùng vẫn là cung tròn bán kính R. Công thức: **vùng phủ trạm i = (hình tròn bán kính Rᵢ) ∩ (ô Voronoi của trạm i)**. Trạm có thiết bị di động (BTS) mất liên lạc → ô tô ĐỎ.
> Ràng buộc chung như Y1–Y4; giữ nguyên các luật Y4 còn hiệu lực: chỉ trạm có BTS tham gia, `interactive:false`, vẽ dưới lớp trạm, mặc định TẮT, bật/tắt không gọi lại API.

## 1. HÌNH HỌC & THUẬT TOÁN (FE tính, một lần mỗi khi dữ liệu đổi — KHÔNG mỗi frame)
1. **Tập điểm tham gia** = các trạm có BTS (`soBts > 0`; thiếu trường thì mọi trạm — luật Y4). Trạm không BTS KHÔNG tham gia chia Voronoi.
2. **Chiếu phẳng cục bộ** trước khi tính (trung trực trên kinh/vĩ độ thô sẽ méo): quy đổi (lat,lng) → mét bằng equirectangular quanh tâm Khánh Hòa (x = R⊕·Δlng·cos(lat₀), y = R⊕·Δlat) — sai số không đáng kể ở phạm vi tỉnh; tính xong chiếu ngược để vẽ Leaflet.
3. **Voronoi**: dùng thư viện **`d3-delaunay`** (≈10KB gzip, chỉ gói này — KHÔNG kéo cả d3). ⚠ Đây là 1 dependency mới — cần PM duyệt trong PR đầu tiên; bị từ chối thì dừng, KHÔNG tự cài thay thế nặng hơn. `Delaunay.from(points).voronoi(bbox)` với bbox = khung Khánh Hòa nới 5km.
4. **Giao với hình tròn**: xấp xỉ đường tròn bán kính Rᵢ (mặc định 500m, ưu tiên `banKinhPhuSong` — luật Y4) bằng đa giác 36 đỉnh; ô Voronoi lồi ∩ đa giác tròn lồi bằng **Sutherland–Hodgman tự viết (~40 dòng)** — không thêm lib. Kết quả: chỗ đông trạm ra cạnh thẳng, chỗ thưa ra cung tròn (đúng ảnh mẫu).
5. **Hiệu năng**: memo hóa theo (danh sách tọa độ + bán kính) — trạng thái đổi CHỈ đổi màu, không tính lại hình; 1.172 trạm phải tính < 200ms; render 1 lớp Polygon Leaflet (bật `preferCanvas` cho pane này nếu SVG lag).

## 2. MÀU & NGỮ NGHĨA (một nguồn phân loại — helper Y1)
- **Trạm có BTS mất liên lạc** (`soBtsMatLienLac > 0` — BE bổ sung 2 trường `soBts`, `soBtsMatLienLac` vào fn trạm-geojson; trường chưa có → fallback trạng thái trạm như Y4): ô fill đỏ `#E24B4A` opacity 0.30 + viền 1.5px cùng màu. Mất điện toàn trạm → BTS tính là mất liên lạc (luật x/x).
- Trạm BTS bình thường (kể cả đang chạy ắc quy): fill xanh `#2E7D32` opacity 0.08, viền ranh giới xám mảnh `#FFFFFF22` (nhìn được lưới ô như ảnh mẫu, không rối).
- Chú giải cập nhật: "Vùng phủ trạm di động (chia theo trạm gần nhất) · Đỏ = khu dân cư mất sóng di động". Tooltip khi hover ô (chỉ bật ở chế độ đa giác, `interactive` riêng pane dưới marker — thứ tự click: trạm > ô phủ): mã trạm · BTS x/y mất liên lạc · bán kính.
- **Chế độ hiển thị trong popover lớp**: radio "Vùng phủ (đa giác — mặc định)" | "Vòng tròn" (giữ code Y4 làm chế độ phụ + fallback khi dependency chưa duyệt). Đổi chế độ không gọi lại API.

## 3. NGHIỆM THU
- [ ] Hai trạm cách nhau < 2R: ranh giới giữa hai ô là đoạn THẲNG trung trực, không vùng chồng lấn; trạm đứng lẻ: ô là hình tròn trọn vẹn 36 đỉnh.
- [ ] Đánh 1 BTS của trạm mất liên lạc → CHỈ ô trạm đó chuyển đỏ ≤3s, hình dạng các ô không tính lại (kiểm console.time); khôi phục → xanh lại.
- [ ] Trạm `MAT_DIEN` còn chạy ắc quy: ô vẫn XANH; trạm `MAT_NGUON`: ô ĐỎ (BTS x/x).
- [ ] `banKinhPhuSong=1500` → ô trạm đó lớn đúng, vẫn bị cắt bởi trung trực với hàng xóm; 1.172 trạm dựng hình < 200ms, pan/zoom không giật.
- [ ] Chuyển chế độ đa giác ↔ vòng tròn tức thì, 0 request mạng; dependency `d3-delaunay` có dòng duyệt của PM trong PR; lint/test xanh.
