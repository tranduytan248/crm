# Y8 — "MẤT LIÊN LẠC" + CỜ TRỌNG YẾU (VIP) + BỐ CỤC LẠI HÀNG KPI DASHBOARD
# (bản giao AI code v1.0 — PM chốt 30/07/2026; làm sau Y1–Y4, phối hợp Y5 ở mục 4)

> Ràng buộc chung + quy tắc migration (TỰ TRA số kế tiếp `ls API/Database/pg/`): như file Y1–Y4. Mọi số hiển thị đều bấm được ra danh sách chứng minh (nguyên tắc "số không bấm được là số không tin được" — giữ tuyệt đối).

## 0. THUẬT NGỮ: "TRẠM MẤT LIÊN LẠC" (đổi NHÃN, KHÔNG đổi MÃ)
- Đổi toàn bộ chữ hiển thị "down / trạm down" → **"mất liên lạc"** trên FE (Dashboard, Bản đồ, Điều phối, Báo cáo, panel, tooltip, chú giải), template Telegram, và nội dung trang Nhiệm vụ (Y7 — sửa các câu có chữ "down" trong `noiDung.js` cho khớp).
- **GIỮ NGUYÊN** enum/mã trạng thái trong DB + API (`MAT_TRUYEN_DAN`, `MAT_NGUON`, `MAT_LIEN_LAC`, `SU_CO`…) và tên biến code — chỉ tầng nhãn. Vẫn tách 2 nguyên nhân bằng màu: đỏ = mất liên lạc do truyền dẫn · cam = mất liên lạc do mất điện.
- Nghiệm thu: `grep -ri "trạm down\|tram down" FrontEnd/src` = 0 (trừ comment kỹ thuật).

## 1. CỜ "TRỌNG YẾU" TRONG DANH MỤC (một khái niệm — nguồn của luật nâng hạng sẵn có)
- Migration mới: `ALTER TABLE trams ADD COLUMN IF NOT EXISTS trong_yeu BOOLEAN NOT NULL DEFAULT FALSE;` — tương tự cho `splitters` (áp cho cả S1 lẫn S2). ⚠ CHỈ lưu cờ bool — **không lưu bất kỳ danh tính/số thuê bao khách VIP nào** (luật bảo mật hackathon: dữ liệu ẩn danh).
- Màn **CSHT (trạm)**: thêm cột "Trọng yếu" (chip ⭐ đỏ đậm khi true) + checkbox trong form (nhãn: "Trạm trọng yếu — có thuê bao VIP, cần ưu tiên xử lý") + cột trong file mẫu import (giá trị 1/0, sai định dạng → lỗi dòng).
- Màn **Splitter**: tương tự — cột "Trọng yếu" + sửa trong form + cột import; bộ lọc nhanh "Chỉ trọng yếu" ở cả hai màn.
- **Cờ trọng yếu là ĐẦU VÀO của luật nâng hạng ưu tiên trạm sẵn có** (P1/P2/P3 + nâng hạng theo khách VIP): hàm suy ưu tiên đọc `trong_yeu=true` → nâng hạng như đặc tả cũ — KHÔNG tạo khái niệm/hàm song song. Panel trạm + tooltip splitter trên bản đồ hiện chip "⭐ Trọng yếu".

## 2. DASHBOARD CHỈ HUY — HÀNG KPI BỐ CỤC MỚI (thay thứ tự v5, vị trí cố định cả 2 nhịp)
Hàng KPI chính — **5 ô đúng thứ tự sau**, mỗi ô drill-down:
1. **UPE mất liên lạc** — "x/y trạm UPE" (viền tím; đủ → "✓ đầy đủ"); drill-down: danh sách trạm UPE + nguyên nhân + giờ.
2. **Trạm di động mất liên lạc** — số TRẠM (cơ sở hạ tầng) có ≥1 thiết bị BTS mất liên lạc; đếm theo TRẠM, không theo thiết bị (trạm 3 BTS cùng mất vẫn = 1); mất điện toàn trạm → tính cả. **Bấm ô → panel "Theo khu vực"** (mục 3) — bảng khu vực TTVT với số trạm di động mất liên lạc từng khu, bấm dòng ra danh sách trạm khu đó (kèm đếm "BTS x/y" + nguyên nhân + 🎯).
3. **S1 | S2 mất liên lạc** — MỘT ô hai số: "S1: a · S2: b" (a, b từ engine lan truyền — một nguồn). **Bấm ô → panel "Theo khu vực"** (mục 3).
4. **Thuê bao mất liên lạc** — giữ công thức + delta 30′ sẵn có.
5. **Doanh thu bị ảnh hưởng** — Σ DT THÁNG trạm mất liên lạc (giữ nguyên luật, khớp 100% drill-down).
- Hai ô cũ "Mạng hoạt động %" và "Lệnh điều động" chuyển thành **dải phụ mỏng** ngay dưới hàng KPI (2 số nhỏ + link) — KHÔNG bỏ dữ liệu. **[PM ĐÃ CHỐT 30/07]**
- Thêm 2 **widget danh sách** đặt ở hàng 2 (cạnh chuỗi lan truyền, co giãn theo nhịp):
  a. **"⭐ Trạm BTS trọng yếu cần xử lý"** — trạm `trong_yeu=true` có BTS mất liên lạc, xếp theo thuê bao ảnh hưởng; mỗi dòng: mã trạm · nguyên nhân · SLA · nút **Phân công** (→ Điều phối `?diemSua=` của điểm sửa chứa trạm; chưa có điểm sửa → nút "Tạo & phân công").
  b. **"⭐ S1|S2 trọng yếu cần xử lý"** — splitter `trong_yeu=true` đang mất liên lạc; mỗi dòng: mã · cấp (badge S1/S2) · trạm OLT · thuê bao nhánh · 🎯 bay bản đồ · liên kết điểm sửa tuyến nếu có.
  Cả hai rỗng → thu về 1 dòng xanh "✓ Không có đối tượng trọng yếu nào đang mất liên lạc".

## 3. DRILL-DOWN THEO KHU VỰC (dùng CHUNG cho ô #2 và ô #3 — một component, hai cấu hình)
- Khu vực = **đơn vị TTVT** (Nha Trang, Diên Khánh, Cam Ranh, Vạn Ninh, Ninh Hòa, Khánh Vĩnh, Khánh Sơn, Cam Lâm — lấy từ cây đơn vị; splitter suy qua trạm→đơn vị; KHÔNG dùng xã).
- **Ô #2 "Trạm di động mất liên lạc"** → bảng: Khu vực · Số trạm di động mất liên lạc · Thuê bao ảnh hưởng · % so toàn tỉnh (thanh mức) — xếp giảm dần; bấm dòng → danh sách TRẠM khu đó (mã trạm · đếm "BTS x/y" mất liên lạc · nguyên nhân · giờ · ⭐ nếu trọng yếu · 🎯).
- **Ô #3 "S1|S2 mất liên lạc"** → bảng: Khu vực · S1 mất liên lạc · S2 mất liên lạc · Thuê bao ảnh hưởng · % — bấm dòng → danh sách splitter khu đó (tái dùng bảng danh mục, lọc sẵn).
- Luật nhất quán: tổng các khu vực = ĐÚNG số ở ô KPI tương ứng; số mất liên lạc lấy từ CÙNG hàm nguồn với KPI (không viết phép đếm thứ hai).
- API: 1 endpoint chung `GET /api/Dashboard/mat-lien-lac-theo-khu-vuc?loai=TRAM_BTS|S1S2` (fn tổng hợp mới join về đơn vị) — một nguồn cho cả hai bảng.

## 4. TRỌNG YẾU CHẢY VÀO ĐIỀU PHỐI **[PM ĐÃ CHỐT 30/07 — code luôn, không chờ]**
- Bậc xếp hàng đợi điểm sửa mới: **UPE (tuyệt đối) > điểm sửa chứa trạm/splitter trọng yếu > khu đã có điện (Y5) > còn lại**; trong cùng bậc giữ tiêu chí thuê bao cứu được. Thẻ điểm sửa trọng yếu gắn chip ⭐.
- Cập nhật hàm xếp hạng (pg/88 + bản Y5) một chỗ duy nhất; 2 widget mục 2 và hàng đợi Điều phối phải cho CÙNG danh sách đối tượng trọng yếu (không lệch).

## 5. NGHIỆM THU
- [ ] Toàn hệ thống không còn chữ "trạm down" trên UI/Telegram/trang Nhiệm vụ; màu 2 nguyên nhân giữ nguyên.
- [ ] Check trọng yếu 1 trạm + 1 S2 (form và import đều thử): chip ⭐ hiện ở danh mục, panel bản đồ; hàm ưu tiên nâng hạng đúng trạm đó; import giá trị sai → lỗi đúng dòng; DB không chứa bất kỳ trường danh tính VIP nào.
- [ ] Hàng KPI đúng thứ tự 5 ô mới ở CẢ 2 nhịp; ô S1|S2 hai số khớp engine lan truyền; dải phụ hiện 2 số cũ.
- [ ] Bấm ô "Trạm di động mất liên lạc" → bảng khu vực TTVT, tổng = đúng số KPI (đếm theo TRẠM: dựng ca 1 trạm có 2 BTS cùng mất → vẫn đếm 1); bấm dòng → danh sách trạm đúng khu, đếm "BTS x/y" đúng.
- [ ] Bấm ô S1|S2 → bảng khu vực TTVT, tổng các dòng = đúng 2 số KPI; bấm dòng → danh sách splitter lọc đúng khu vực; cả hai bảng dùng chung một component + một endpoint.
- [ ] 2 widget trọng yếu: dựng ca demo (1 trạm ⭐ có BTS mất liên lạc + 1 S2 ⭐ mất liên lạc do đứt tuyến) → hiện đúng, nút Phân công/🎯 dẫn đúng; hết ca → thu về dòng xanh.
- [ ] Điểm sửa chứa đối tượng ⭐ đứng ngay sau UPE, trước khu-có-điện; lint/test FE + build/test BE xanh; migration idempotent.
