# Storyboard
Mỗi scene gồm: hình ảnh, thoại, camera, âm thanh.
