# Camera
Drone, dolly, close-up, aerial, slow motion.
