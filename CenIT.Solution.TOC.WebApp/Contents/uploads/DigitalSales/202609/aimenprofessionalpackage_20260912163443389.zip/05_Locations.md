# Locations
Biển Đông, NOC VNPT KH, BTS, POP, đường ven biển, khu dân cư.
