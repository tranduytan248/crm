# Âm thanh
Gió, mưa, cinematic, kết thúc hùng tráng.
