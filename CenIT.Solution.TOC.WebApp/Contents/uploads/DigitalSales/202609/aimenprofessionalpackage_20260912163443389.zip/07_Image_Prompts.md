# Image Prompts
Prompt tạo nhân vật và bối cảnh.
