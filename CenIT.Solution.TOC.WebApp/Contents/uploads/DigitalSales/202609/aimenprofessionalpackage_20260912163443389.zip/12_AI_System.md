# Hệ thống AI
Kiến trúc dữ liệu, dashboard, mô phỏng.
