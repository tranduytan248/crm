# Characters
AI MEN, 5 kỹ sư Trung tâm Hạ tầng, Lãnh đạo Viễn thông KH, người dân.
