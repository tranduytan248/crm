# Story
Câu chuyện gồm 7 hồi: Damrey 2017 -> Cảnh báo -> AI MEN -> Báo cáo -> Chỉ huy -> Khắc phục -> Ăn mừng.
