# Scenes
Liệt kê 45 scene, mỗi scene 5-8 giây (placeholder để phát triển).
