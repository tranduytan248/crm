# Veo3 Prompts
Prompt điện ảnh cho từng phân đoạn.
